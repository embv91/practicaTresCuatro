# Color Shades Generator App

- You can clone this repository to get the source code on your PC and then run `npm install` to install dependencies and packages.
- `npm start` helps you start the server locally.

API - [values.js](https://noeldelgado.github.io/values.js/)


Live URL deployed [here](https://colorshadess-generator.netlify.app/).
